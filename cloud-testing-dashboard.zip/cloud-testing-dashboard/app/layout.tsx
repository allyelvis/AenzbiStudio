import './globals.css'
import { Inter } from 'next/font/google'
import { Navbar } from './components/Navbar'

const inter = Inter({ subsets: ['latin'] })

export const metadata = {
  title: 'Enhanced Cloud Testing Dashboard',
  description: 'Test your projects across multiple platforms with integrated development environment',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <Navbar />
        <div className="p-4">
          {children}
        </div>
      </body>
    </html>
  )
}

