import { NextResponse } from 'next/server'
import { exec } from 'child_process'
import { promisify } from 'util'

const execAsync = promisify(exec)

const ALLOWED_COMMANDS = ['ls', 'pwd', 'echo', 'date']

export async function POST(req: Request) {
  const { command } = await req.json()

  const commandName = command.split(' ')[0]

  if (!ALLOWED_COMMANDS.includes(commandName)) {
    return NextResponse.json({ error: 'Command not allowed' }, { status: 403 })
  }

  try {
    const { stdout, stderr } = await execAsync(command)
    return NextResponse.json({ output: stdout || stderr })
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

