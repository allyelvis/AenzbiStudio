import { NextResponse } from 'next/server'
import { Configuration, OpenAIApi } from 'openai-edge'

const config = new Configuration({
  apiKey: process.env.OPENAI_API_KEY
})
const openai = new OpenAIApi(config)

export async function POST(req: Request) {
  const { model } = await req.json()

  try {
    const response = await openai.createChatCompletion({
      model: model,
      messages: [
        { role: 'system', content: 'You are an AI tasked with optimizing a cloud testing environment.' },
        { role: 'user', content: 'Suggest improvements for our cloud testing dashboard.' }
      ],
    })

    const result = await response.json()
    const suggestion = result.choices[0].message.content

    // Here, you would typically implement logic to apply the AI's suggestions
    // For this example, we'll just return the suggestion
    return NextResponse.json({ message: `Optimization suggestion: ${suggestion}` })
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

