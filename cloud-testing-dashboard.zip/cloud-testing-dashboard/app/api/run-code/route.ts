import { NextResponse } from 'next/server'
import { exec } from 'child_process'
import { promisify } from 'util'

const execAsync = promisify(exec)

export async function POST(req: Request) {
  const { code, language } = await req.json()

  let command
  switch (language) {
    case 'javascript':
      command = `node -e "${code.replace(/"/g, '\\"')}"`
      break
    case 'python':
      command = `python -c "${code.replace(/"/g, '\\"')}"`
      break
    case 'java':
      // For Java, we need to write to a file, compile, and run
      // This is a simplified version and might not work for all Java code
      command = `echo "${code.replace(/"/g, '\\"')}" > Main.java && javac Main.java && java Main`
      break
    case 'csharp':
      // For C#, we need to write to a file, compile, and run
      // This is a simplified version and might not work for all C# code
      command = `echo "${code.replace(/"/g, '\\"')}" > Program.cs && dotnet run Program.cs`
      break
    default:
      return NextResponse.json({ error: 'Unsupported language' }, { status: 400 })
  }

  try {
    const { stdout, stderr } = await execAsync(command)
    return NextResponse.json({ output: stdout || stderr })
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

