'use client'

import { useState, useEffect, useRef } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Code, Terminal, Play, Bug } from 'lucide-react'
import Editor, { useMonaco } from "@monaco-editor/react"
import { io } from 'socket.io-client'
import { useCompletion } from 'ai/react'

export default function DevelopmentEnvironment() {
  const [selectedLanguage, setSelectedLanguage] = useState('javascript')
  const [code, setCode] = useState('// Write your code here')
  const [output, setOutput] = useState('')
  const [isDebugging, setIsDebugging] = useState(false)
  const [breakpoints, setBreakpoints] = useState([])
  const editorRef = useRef(null)
  const monaco = useMonaco()
  const socketRef = useRef(null)

  useEffect(() => {
    // Initialize socket connection for real-time collaboration
    socketRef.current = io('http://localhost:3001')
    socketRef.current.on('code-change', (newCode) => {
      setCode(newCode)
    })

    return () => {
      socketRef.current.disconnect()
    }
  }, [])

  const handleEditorDidMount = (editor, monaco) => {
    editorRef.current = editor
    // Set up collaboration
    editor.onDidChangeModelContent(() => {
      const newCode = editor.getValue()
      socketRef.current.emit('code-change', newCode)
    })
  }

  const handleRunCode = async () => {
    try {
      setOutput('Running code...')
      const response = await fetch('/api/run-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code, language: selectedLanguage }),
      })
      const result = await response.json()
      setOutput(result.output)
    } catch (error) {
      setOutput(`Error: ${error.message}`)
    }
  }

  const handleDebug = () => {
    setIsDebugging(!isDebugging)
    if (!isDebugging) {
      setOutput('Debugger started. Set breakpoints and run your code.')
    } else {
      setOutput('Debugger stopped.')
    }
  }

  const handleSetBreakpoint = (event) => {
    if (isDebugging && editorRef.current) {
      const lineNumber = event.target.lineNumber
      const currentBreakpoints = editorRef.current.getModel().getAllDecorations()
        .filter(d => d.options.isWholeLine && d.options.className === 'breakpoint')
        .map(d => d.range.startLineNumber)

      if (currentBreakpoints.includes(lineNumber)) {
        editorRef.current.deltaDecorations([{ range: new monaco.Range(lineNumber, 1, lineNumber, 1), options: { isWholeLine: true, className: 'breakpoint' } }], [])
        setBreakpoints(currentBreakpoints.filter(bp => bp !== lineNumber))
      } else {
        editorRef.current.deltaDecorations([], [{ range: new monaco.Range(lineNumber, 1, lineNumber, 1), options: { isWholeLine: true, className: 'breakpoint' } }])
        setBreakpoints([...currentBreakpoints, lineNumber])
      }
    }
  }

  const { complete } = useCompletion({
    api: '/api/code-completion',
  })

  const handleAIAssist = async () => {
    if (editorRef.current) {
      const selection = editorRef.current.getSelection()
      const selectedText = editorRef.current.getModel().getValueInRange(selection)
      
      try {
        const completion = await complete(selectedText)
        editorRef.current.executeEdits('ai-assist', [{
          range: selection,
          text: completion,
        }])
      } catch (error) {
        setOutput(`AI Assist Error: ${error.message}`)
      }
    }
  }

  return (
    <Card className="col-span-1">
      <CardHeader>
        <CardTitle>Development Environment</CardTitle>
        <CardDescription>Edit, compile, and debug your code</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="editor" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="editor" className="flex items-center"><Code className="w-4 h-4 mr-2" /> Editor</TabsTrigger>
            <TabsTrigger value="debugger" className="flex items-center"><Bug className="w-4 h-4 mr-2" /> Debugger</TabsTrigger>
            <TabsTrigger value="compiler" className="flex items-center"><Play className="w-4 h-4 mr-2" /> Compiler</TabsTrigger>
            <TabsTrigger value="terminal" className="flex items-center"><Terminal className="w-4 h-4 mr-2" /> Terminal</TabsTrigger>
          </TabsList>
          <TabsContent value="editor">
            <div className="space-y-4">
              <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Select language" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="javascript">JavaScript</SelectItem>
                  <SelectItem value="python">Python</SelectItem>
                  <SelectItem value="java">Java</SelectItem>
                  <SelectItem value="csharp">C#</SelectItem>
                </SelectContent>
              </Select>
              <Editor
                height="400px"
                language={selectedLanguage}
                value={code}
                onChange={setCode}
                onMount={handleEditorDidMount}
                options={{
                  minimap: { enabled: false },
                  lineNumbers: 'on',
                  roundedSelection: false,
                  scrollBeyondLastLine: false,
                  readOnly: false,
                  theme: 'vs-dark',
                }}
              />
              <div className="flex justify-between">
                <Button onClick={handleRunCode}>Run Code</Button>
                <Button onClick={handleDebug} variant="outline">
                  {isDebugging ? 'Stop Debugging' : 'Start Debugging'}
                </Button>
                <Button onClick={handleAIAssist} variant="outline">AI Assist</Button>
              </div>
            </div>
          </TabsContent>
          <TabsContent value="debugger">
            <div className="space-y-4">
              <p>Debugger Console</p>
              <pre className="bg-gray-100 p-4 rounded-md h-64 overflow-auto">
                {output || 'Debugger ready. Set breakpoints in your code and start debugging.'}
              </pre>
              {isDebugging && (
                <div>
                  <p>Breakpoints:</p>
                  <ul>
                    {breakpoints.map((line) => (
                      <li key={line}>Line {line}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </TabsContent>
          <TabsContent value="compiler">
            <div className="space-y-4">
              <p>Compiler Output</p>
              <pre className="bg-gray-100 p-4 rounded-md h-64 overflow-auto">
                {output || 'Compiler ready. Run your code to see output.'}
              </pre>
            </div>
          </TabsContent>
          <TabsContent value="terminal">
            <div className="space-y-4">
              <p>Shell Terminal</p>
              <pre className="bg-black text-green-400 p-4 rounded-md h-64 overflow-auto font-mono">
                $ {output || 'Welcome to the shell. Type your commands here.'}
              </pre>
              <input
                type="text"
                className="w-full p-2 border rounded-md font-mono text-sm"
                placeholder="Enter command..."
                onKeyPress={async (e) => {
                  if (e.key === 'Enter') {
                    const command = e.currentTarget.value
                    setOutput(`$ ${command}\nExecuting command...`)
                    e.currentTarget.value = ''
                    try {
                      const response = await fetch('/api/shell-command', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ command }),
                      })
                      const result = await response.json()
                      setOutput(result.output)
                    } catch (error) {
                      setOutput(`Error: ${error.message}`)
                    }
                  }
                }}
              />
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

