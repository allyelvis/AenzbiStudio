'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { SmartphoneIcon as Android, Apple, Globe, ComputerIcon as Windows, Github, Cloud, Trello } from 'lucide-react'

type Platform = 'android' | 'ios' | 'web' | 'windows'

const platforms: Record<Platform, { name: string; icon: React.ReactNode }> = {
  android: { name: 'Android', icon: <Android className="w-6 h-6" /> },
  ios: { name: 'iOS', icon: <Apple className="w-6 h-6" /> },
  web: { name: 'Web', icon: <Globe className="w-6 h-6" /> },
  windows: { name: 'Windows', icon: <Windows className="w-6 h-6" /> },
}

export default function TestingDashboard() {
  const [selectedPlatform, setSelectedPlatform] = useState<Platform>('android')
  const [isTestRunning, setIsTestRunning] = useState(false)
  const [visualDiff, setVisualDiff] = useState<string | null>(null)

  const handleRunTest = () => {
    setIsTestRunning(true)
    // Simulate a test run
    setTimeout(() => {
      setIsTestRunning(false)
      // Simulate a visual difference
      setVisualDiff('/placeholder.svg?height=300&width=500')
    }, 3000)
  }

  return (
    <Card className="col-span-1">
      <CardHeader>
        <CardTitle>Testing Dashboard</CardTitle>
        <CardDescription>Run tests and view results</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div className="flex items-center space-x-4">
            <Select value={selectedPlatform} onValueChange={(value: Platform) => setSelectedPlatform(value)}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select platform" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(platforms).map(([key, { name }]) => (
                  <SelectItem key={key} value={key}>{name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button onClick={handleRunTest} disabled={isTestRunning}>
              {isTestRunning ? 'Running Test...' : 'Run Test'}
            </Button>
          </div>

          <div className="flex items-center space-x-4">
            {platforms[selectedPlatform].icon}
            <span className="text-lg font-medium">{platforms[selectedPlatform].name}</span>
            <span className={`px-2 py-1 rounded-full text-xs font-medium ${isTestRunning ? 'bg-yellow-200 text-yellow-800' : 'bg-green-200 text-green-800'}`}>
              {isTestRunning ? 'Testing' : 'Ready'}
            </span>
          </div>

          <Tabs defaultValue="console" className="w-full">
            <TabsList>
              <TabsTrigger value="console">Console Output</TabsTrigger>
              <TabsTrigger value="visual">Visual Diff</TabsTrigger>
            </TabsList>
            <TabsContent value="console">
              <pre className="bg-gray-100 p-4 rounded-md h-[200px] overflow-auto">
                {isTestRunning ? 'Running tests...' : 'Test completed. No issues found.'}
              </pre>
            </TabsContent>
            <TabsContent value="visual">
              {visualDiff ? (
                <div className="relative">
                  <img src={visualDiff} alt="Visual difference" className="w-full h-auto" />
                  <div className="absolute top-2 left-2 bg-red-500 text-white px-2 py-1 rounded">Differences detected</div>
                </div>
              ) : (
                <div className="h-[200px] flex items-center justify-center bg-gray-100 rounded-md">
                  No visual differences detected
                </div>
              )}
            </TabsContent>
          </Tabs>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="github" className="flex items-center gap-2 mb-2">
                <Github className="w-4 h-4" /> GitHub
              </Label>
              <Input id="github" placeholder="Enter GitHub repository URL" />
            </div>
            <div>
              <Label htmlFor="azure" className="flex items-center gap-2 mb-2">
                <Cloud className="w-4 h-4" /> Azure DevOps
              </Label>
              <Input id="azure" placeholder="Enter Azure DevOps project URL" />
            </div>
            <div>
              <Label htmlFor="gcloud" className="flex items-center gap-2 mb-2">
                <Cloud className="w-4 h-4" /> Google Cloud
              </Label>
              <Input id="gcloud" placeholder="Enter Google Cloud project ID" />
            </div>
            <div>
              <Label htmlFor="jira" className="flex items-center gap-2 mb-2">
                <Trello className="w-4 h-4" /> Jira
              </Label>
              <Input id="jira" placeholder="Enter Jira project URL" />
            </div>
          </div>
          <Button className="w-full">Connect Integrations</Button>
        </div>
      </CardContent>
    </Card>
  )
}

