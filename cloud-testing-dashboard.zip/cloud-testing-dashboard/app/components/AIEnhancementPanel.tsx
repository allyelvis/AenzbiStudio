'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useChat } from 'ai/react'

export default function AIEnhancementPanel() {
  const [selectedModel, setSelectedModel] = useState('gpt-4')
  const { messages, input, handleInputChange, handleSubmit } = useChat({
    api: '/api/chat',
  })

  const [isOptimizing, setIsOptimizing] = useState(false)
  const [optimizationResult, setOptimizationResult] = useState('')

  const handleOptimize = async () => {
    setIsOptimizing(true)
    try {
      const response = await fetch('/api/optimize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: selectedModel }),
      })
      const result = await response.json()
      setOptimizationResult(result.message)
    } catch (error) {
      setOptimizationResult('Optimization failed: ' + error.message)
    }
    setIsOptimizing(false)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>AI Enhancement Panel</CardTitle>
        <CardDescription>Leverage AI to improve and maintain your cloud environment</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="chat">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="chat">AI Assistant</TabsTrigger>
            <TabsTrigger value="optimize">Self-Optimization</TabsTrigger>
          </TabsList>
          <TabsContent value="chat">
            <div className="space-y-4">
              <div className="border rounded-lg p-4 h-64 overflow-auto">
                {messages.map((m, index) => (
                  <div key={index} className={`mb-4 ${m.role === 'user' ? 'text-blue-600' : 'text-green-600'}`}>
                    <strong>{m.role === 'user' ? 'You: ' : 'AI: '}</strong>{m.content}
                  </div>
                ))}
              </div>
              <form onSubmit={handleSubmit} className="flex gap-2">
                <Input
                  value={input}
                  onChange={handleInputChange}
                  placeholder="Ask the AI assistant for help..."
                />
                <Button type="submit">Send</Button>
              </form>
            </div>
          </TabsContent>
          <TabsContent value="optimize">
            <div className="space-y-4">
              <div>
                <Label htmlFor="model-select">Select AI Model</Label>
                <select
                  id="model-select"
                  value={selectedModel}
                  onChange={(e) => setSelectedModel(e.target.value)}
                  className="w-full p-2 border rounded-md"
                >
                  <option value="gpt-4">GPT-4</option>
                  <option value="gpt-3.5-turbo">GPT-3.5 Turbo</option>
                </select>
              </div>
              <Button onClick={handleOptimize} disabled={isOptimizing}>
                {isOptimizing ? 'Optimizing...' : 'Start Self-Optimization'}
              </Button>
              {optimizationResult && (
                <div className="border rounded-lg p-4 mt-4">
                  <h3 className="font-bold mb-2">Optimization Result:</h3>
                  <p>{optimizationResult}</p>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

