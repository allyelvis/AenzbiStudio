import { Suspense } from 'react'
import TestingDashboard from './components/TestingDashboard'
import DevelopmentEnvironment from './components/DevelopmentEnvironment'
import AIEnhancementPanel from './components/AIEnhancementPanel'
import AuthWrapper from './components/AuthWrapper'

export default function Home() {
  return (
    <AuthWrapper>
      <main className="container mx-auto p-4">
        <h1 className="text-3xl font-bold mb-6">AI-Enhanced Cloud Testing Dashboard</h1>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Suspense fallback={<div>Loading Testing Dashboard...</div>}>
            <TestingDashboard />
          </Suspense>
          <Suspense fallback={<div>Loading Development Environment...</div>}>
            <DevelopmentEnvironment />
          </Suspense>
        </div>
        <div className="mt-6">
          <Suspense fallback={<div>Loading AI Enhancement Panel...</div>}>
            <AIEnhancementPanel />
          </Suspense>
        </div>
      </main>
    </AuthWrapper>
  )
}

